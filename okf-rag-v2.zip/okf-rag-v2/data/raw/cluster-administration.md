# Cluster Administration

The cluster administration overview is for anyone creating or administering a Kubernetes cluster.
It assumes some familiarity with core Kubernetes concepts.

## Planning a cluster

See the guides in Setup for examples of how to plan, set up, and configure
Kubernetes clusters. The solutions listed in this article are called *distros*.

Not all distros are actively maintained. Choose distros which have been tested with a recent
version of Kubernetes.

Before choosing a guide, here are some considerations:

- Do you want to try out Kubernetes on your computer, or do you want to build a high-availability,
  multi-node cluster? Choose distros best suited for your needs.
- Will you be using **a hosted Kubernetes cluster**, such as
  Google Kubernetes Engine, or **hosting your own cluster**?
- Will your cluster be **on-premises**, or **in the cloud (IaaS)**? Kubernetes does not directly
  support hybrid clusters. Instead, you can set up multiple clusters.
- **If you are configuring Kubernetes on-premises**, consider which
  networking model fits best.
- Will you be running Kubernetes on **"bare metal" hardware** or on **virtual machines (VMs)**?
- Do you **want to run a cluster**, or do you expect to do **active development of Kubernetes project code**?
  If the latter, choose an actively-developed distro. Some distros only use binary releases, but
  offer a greater variety of choices.
- Familiarize yourself with the components needed to run a cluster.

## Managing a cluster

* Learn how to manage nodes.
  * Read about Node autoscaling.

* Learn how to set up and manage the resource quota for shared clusters.

## Securing a cluster

* Generate Certificates describes the steps to
  generate certificates using different tool chains.

* Kubernetes Container Environment describes
  the environment for Kubelet managed containers on a Kubernetes node.

* Controlling Access to the Kubernetes API describes
  how Kubernetes implements access control for its own API.

* Authenticating explains authentication in
  Kubernetes, including the various authentication options.

* Authorization is separate from
  authentication, and controls how HTTP calls are handled.

* Using Admission Controllers
  explains plug-ins which intercepts requests to the Kubernetes API server after authentication
  and authorization.

* Admission Webhook Good Practices
  provides good practices and considerations when designing mutating admission
  webhooks and validating admission webhooks.

* Using Sysctls in a Kubernetes Cluster
  describes to an administrator how to use the `sysctl` command-line tool to set kernel parameters
.

* Auditing describes how to interact with Kubernetes'
  audit logs.

### Securing the kubelet

* Control Plane-Node communication
* TLS bootstrapping
* Kubelet authentication/authorization

## Optional Cluster Services

* DNS Integration describes how to resolve
  a DNS name directly to a Kubernetes service.

* Logging and Monitoring Cluster Activity
  explains how logging in Kubernetes works and how to implement it.
